#include "..\\James.Cpp.Api\\James.Cpp.Api.hpp"
#include <windows.h>
#include <cstdio>
#include <cstdlib>
#include <ctime>

using namespace James;
using namespace James::Cpp;

enum Gender : Byte
{
    NotSpecified = 0,
    Male = 1,
    Female = 2
};

class Person
{
public:
    Person() throw();
    Person(const CAnsiString & strFirstName, const CAnsiString & strLastName, ULong32 nAge, Gender enGender) throw();
    Person(const Person & obj) throw();
    virtual ~Person() throw();

    inline const CAnsiString & GetFirstName() const { return m_strFirstName; }
    inline const CAnsiString & GetLastName() const { return m_strLastName; }
    inline ULong32 GetAge() const { return m_nAge; }
    inline Gender GetGender() const { return m_enGender; }

    void PrintToConsole() const throw();

    Person & operator= (const Person & obj) throw();

    static Person RandomPerson() throw();
protected:
    CAnsiString m_strFirstName;
    CAnsiString m_strLastName;
    ULong32 m_nAge;
    Gender m_enGender;
};

namespace James
{
    namespace Cpp
    {
        template class __declspec(dllexport) TArray<Person>;
    }
}

int main(int argc, char * argv[]) throw()
{
    TArray<Person> myRandomArray(static_cast<SizeT>(32), 0, 16);

    srand(::GetTickCount());


        myRandomArray.Add(Person::RandomPerson(), 16);

    TArray<Person> temp(static_cast<SizeT>(16),0,16);

    myRandomArray.Add(myRandomArray, 5, 3);


    printf("There are %lu Person objects in the array.\n", myRandomArray.GetCount());

    system("pause");

    return 0;
}

Person::Person() throw() : m_strFirstName(), m_strLastName(), m_nAge(0), m_enGender(Gender::NotSpecified)
{

}

Person::Person(const CAnsiString & strFirstName, const CAnsiString & strLastName, ULong32 nAge, Gender enGender) throw() : m_strFirstName(strFirstName),
    m_strLastName(strLastName), m_nAge(nAge), m_enGender(enGender)
{

}

Person::Person(const Person & obj) throw() : m_strFirstName(obj.m_strFirstName), m_strLastName(obj.m_strLastName),
    m_nAge(obj.m_nAge), m_enGender(obj.m_enGender)
{

}

Person::~Person() throw()
{
}

void Person::PrintToConsole() const throw()
{
    if (m_strFirstName.GetLength() != 0)
    {
        printf("FirstName: %s\t", m_strFirstName.GetData());
    }

    if (m_strLastName.GetLength() != 0)
    {
        printf("LastName: %s\t", m_strLastName.GetData());
    }

    if (m_nAge != 0)
    {
        printf("Age: %lu\t", m_nAge);
    }



    if (m_enGender == Gender::Male)
    {
        printf("Gender: Male");
    }
    else if (m_enGender == Gender::Female)
    {
        printf("Gender: Female");
    }

    printf("\n");
}

Person & Person::operator= (const Person & obj) throw()
{
    if (this != &obj)
    {
        m_strFirstName = obj.m_strFirstName;
        m_strLastName = obj.m_strLastName;
        m_nAge = obj.m_nAge;
        m_enGender = obj.m_enGender;
    }

    return *this;
}

Person Person::RandomPerson() throw()
{
    // Names for picking at random
    // It would be better to have a text file with each line have a name to read
    // but this is just an example
    const CAnsiString arFirstNames[8] = { "James", "Laura", "Vanessa", "Michael", "Robert", "Emily", "Vincent", "Micayla" };

    int nValue = rand() % 8;

    const CAnsiString & strFirstNameRef = arFirstNames[nValue];

    nValue = (rand() % 101) + 18;

    const int nAge = nValue;

    Gender enGender = Gender::NotSpecified;

    return Person(strFirstNameRef,CAnsiString(), nAge, enGender);
}
