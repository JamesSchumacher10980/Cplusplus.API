#include "StdAfx.hpp"
#include "James.Cpp.Api.hpp"

namespace James
{
    namespace Cpp
    {
        IDelegate::~IDelegate() throw()
        {

        }

        ICallback::~ICallback() throw()
        {
        }
    }
}
