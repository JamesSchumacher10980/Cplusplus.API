#include "StdAfx.hpp"
#include "James.Cpp.Api.hpp"

namespace James
{
    namespace Cpp
    {
        IBaseStream::~IBaseStream() throw()
        {

        }

        IReadableStream::~IReadableStream() throw()
        {
        }

        IWritableStream::~IWritableStream() throw()
        {
        }

        ISeekableStream::~ISeekableStream() throw()
        {
        }

        IStream::~IStream() throw()
        {
        }
    }
}
